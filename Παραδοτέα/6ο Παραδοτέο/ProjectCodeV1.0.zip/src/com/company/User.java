package com.company;

//H klassi auti periexei ta stoixeia tou user
public class User {


    public String id;
    public String username;
    public String surname;
    public String name;
    public String email;
    public String password;
    public String vehicle_id;




}
