package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;


public abstract class Main extends Parking {

    public static  void main(String[] args) throws SQLException, ClassNotFoundException {


        AppUI appUI = new AppUI();

        //SwingUtilities.invokeLater(Parking::new);












    }
}